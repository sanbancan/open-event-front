import 'open-event-frontend/extensions/ember-table/component';

export function initialize() {}

export default {
  name: 'extensions',
  initialize
};
