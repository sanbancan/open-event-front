import component from 'ember-table/components/ember-table/component';
import layout from './template';

component.reopen({
  layout
});
