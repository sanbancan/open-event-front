import { A } from '@ember/array';
import Component from '@ember/component';

export default Component.extend({
  classNames: ['ui', 'basic', 'segment', 'm-0', 'p-0', 'pb-2'],

  socialLinks: A()
});
