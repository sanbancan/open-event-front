import classic from 'ember-classic-decorator';
import ModalBase from 'open-event-frontend/components/modals/modal-base';

@classic
export default class ProposalDeleteModal extends ModalBase {
  isSmall = true;
}
