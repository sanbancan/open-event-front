import nouislider from 'ember-cli-nouislider/components/range-slider';

export default nouislider;

